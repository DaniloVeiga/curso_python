# -*- coding: utf-8 -*-
# Exemplo 056 — Formatar células #21
# Ao executar, um arquivo XLSX será criado na pasta 'saidas/'.
import os
from datetime import datetime, date
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment, NamedStyle
from openpyxl.formatting.rule import CellIsRule, FormulaRule, ColorScaleRule, IconSetRule, DataBarRule
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.chart import LineChart, BarChart, PieChart, DoughnutChart, ScatterChart, BubbleChart, AreaChart, RadarChart, Reference, Series
from openpyxl.drawing.image import Image as XLImage
os.makedirs('saidas', exist_ok=True)
wb = Workbook(); ws = wb.active
ws['A1'] = 'Negrito'
ws['A1'].font = Font(bold=True)
ws['B1'] = 1234.56
ws['B1'].number_format = 'R$ #,##0.00'
ws['C1'] = 'Fundo'
ws['C1'].fill = PatternFill('solid', fgColor='FFFFAA')
saida = 'saidas/ex056_estilo21.xlsx'
wb.save(saida)
print('OK - Gerado:', saida)
