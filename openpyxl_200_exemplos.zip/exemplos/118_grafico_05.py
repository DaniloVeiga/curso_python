# -*- coding: utf-8 -*-
# Exemplo 118 — Gráfico básico #5
# Ao executar, um arquivo XLSX será criado na pasta 'saidas/'.
import os
from datetime import datetime, date
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment, NamedStyle
from openpyxl.formatting.rule import CellIsRule, FormulaRule, ColorScaleRule, IconSetRule, DataBarRule
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.chart import LineChart, BarChart, PieChart, DoughnutChart, ScatterChart, BubbleChart, AreaChart, RadarChart, Reference, Series
from openpyxl.drawing.image import Image as XLImage
os.makedirs('saidas', exist_ok=True)
wb = Workbook(); ws = wb.active
ws.append(['Cat','S1','S2'])
for i in range(1,6): ws.append([f'C{i}', i, i*2])
chart = BarChart(); chart.type='col'; chart.title='Exemplo'
chart.add_data(Reference(ws, min_col=2, max_col=3, min_row=1, max_row=6), titles_from_data=True)
chart.set_categories(Reference(ws, min_col=1, min_row=2, max_row=6))
ws.add_chart(chart, 'E2')
saida = 'saidas/ex118_chart5.xlsx'
wb.save(saida)
print('OK - Gerado:', saida)
