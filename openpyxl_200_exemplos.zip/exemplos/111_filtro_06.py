# -*- coding: utf-8 -*-
# Exemplo 111 — AutoFilter e impressão #6
# Ao executar, um arquivo XLSX será criado na pasta 'saidas/'.
import os
from datetime import datetime, date
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment, NamedStyle
from openpyxl.formatting.rule import CellIsRule, FormulaRule, ColorScaleRule, IconSetRule, DataBarRule
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.chart import LineChart, BarChart, PieChart, DoughnutChart, ScatterChart, BubbleChart, AreaChart, RadarChart, Reference, Series
from openpyxl.drawing.image import Image as XLImage
os.makedirs('saidas', exist_ok=True)
wb = Workbook(); ws = wb.active
ws.append(['Status','Valor'])
for st,v in [('OK',1),('NOK',2),('OK',3),('NOK',4)]: ws.append([st,v])
ws.auto_filter.ref = 'A1:B5'
saida = 'saidas/ex111_filtro6.xlsx'
wb.save(saida)
print('OK - Gerado:', saida)
