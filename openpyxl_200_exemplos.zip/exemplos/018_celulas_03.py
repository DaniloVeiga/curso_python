# -*- coding: utf-8 -*-
# Exemplo 018 — Operações básicas com células #3
# Ao executar, um arquivo XLSX será criado na pasta 'saidas/'.
import os
from datetime import datetime, date
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment, NamedStyle
from openpyxl.formatting.rule import CellIsRule, FormulaRule, ColorScaleRule, IconSetRule, DataBarRule
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.chart import LineChart, BarChart, PieChart, DoughnutChart, ScatterChart, BubbleChart, AreaChart, RadarChart, Reference, Series
from openpyxl.drawing.image import Image as XLImage
os.makedirs('saidas', exist_ok=True)
wb = Workbook(); ws = wb.active
ws.append(['Produto','Qtde','Preço'])
for i in range(1,6): ws.append([f'Item {i}', i*2, i*10.5])
ws['E1'] = 'Soma Qtde'
ws['E2'] = '=SUM(B2:B6)'
saida = 'saidas/ex018_cel3.xlsx'
wb.save(saida)
print('OK - Gerado:', saida)
