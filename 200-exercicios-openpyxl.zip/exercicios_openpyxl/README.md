
# 200 Exercícios Básicos de openpyxl

Este pacote contém **200 exercícios** para praticar **openpyxl** (manipulação de arquivos Excel via Python).

## Como usar
1. Garanta que você tenha `openpyxl` instalado: `pip install openpyxl`.
2. Em cada exercício, rode o bloco **Arquivo base** uma vez para criar `base.xlsx`.
3. Execute as **Tarefas** propostas (salve com nomes como `ex001.xlsx`, `ex002.xlsx`, etc.).
4. Abra o arquivo resultante no Excel/LibreOffice para conferir o efeito.

## Abrangência dos tópicos
- Criação de workbook/planilhas
- Células, intervalos, iteração e cálculos simples
- Estilos, formatos, números e datas
- Validações e proteção
- Formatação condicional
- Tabelas e AutoFilter
- Comentários, hyperlinks e imagens
- Configurações de página e impressão
- Operações básicas de I/O (carregar/salvar/cópias)

> **Observação**: Os dados são **pequenos** e inseridos por código para facilitar a prática sem depender de arquivos externos.

## Licença
Uso livre para estudo e treinamento.
