
# 200 Exercícios Básicos de pandas

Bem-vindo(a)! Este pacote contém **200 exercícios** de nível básico para praticar **pandas** (Python).

## Como usar
1. Garanta que você tenha `pandas` instalado (por exemplo: `pip install pandas`).
2. Abra cada arquivo em `exercicios/` (ex001.md até ex200.md).
3. Cada exercício contém um **dataset base** (um pequeno DataFrame) e uma lista de **tarefas**.
4. Copie o código do dataset para o seu ambiente (Jupyter/VS Code/Terminal) e resolva as tarefas.
5. Dica: crie um notebook e resolva 5 a 10 exercícios por sessão.

## Abrangência
Os exercícios cobrem:
- Criação e inspeção de Series/DataFrames
- Seleção com `loc`/`iloc`/`at`/`iat`
- Filtragem e condições
- Operações em colunas e tipos
- Valores ausentes (`isna`/`fillna`/`dropna`)
- Ordenação, ranking e duplicatas
- GroupBy e agregações
- Junções e concatenações (`merge`/`concat`)
- Reshape: `pivot`, `melt` e `crosstab`
- Datas, tempo e I/O básico

> **Observação**: Estes exercícios usam **datasets pequenos** gerados no próprio código para facilitar a prática sem dependências externas.

## Licença
Uso livre para estudo e treinamento.
