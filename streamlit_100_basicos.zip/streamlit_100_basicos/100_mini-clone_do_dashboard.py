# -*- coding: utf-8 -*-
import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Mini-Clone do Dashboard", layout="wide")
st.title("Mini-Clone do Dashboard")
st.caption("estrutura mínima")

up = st.file_uploader('Excel', type=['xlsx'])
if up:
    xl = pd.ExcelFile(up, engine='openpyxl')
    aba = st.radio('Aba', ['STATUS_GERAL','EORD','MS'])
    if aba in xl.sheet_names:
        df = xl.parse(aba)
        st.dataframe(df.head())
        if aba=='STATUS_GERAL' and set(['Fornecedor','Material']).issubset(df.columns):
            top = (
                df.groupby('Fornecedor')['Material']
                  .nunique()
                  .reset_index()
                  .sort_values('Material', ascending=False)
                  .head(10)
            )
            st.plotly_chart(px.bar(top, x='Material', y='Fornecedor', orientation='h'))
