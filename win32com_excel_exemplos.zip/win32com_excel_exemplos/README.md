
# Exercícios de Automação Excel com `win32com.client`

Este pacote contém 100 exemplos básicos para praticar automação do Microsoft Excel via COM (pywin32) em Windows.

## Como usar
1. Garanta que você está no Windows com Excel instalado.
2. Instale o pywin32:
   ```bash
   pip install pywin32
   ```
3. Execute qualquer exemplo:
   ```bash
   python ex01.py
   ```

Observações:
- Alguns exemplos salvam arquivos em sua pasta atual (ajuste caminhos conforme necessário).
- Enumerações do Excel são números inteiros (ex.: `51` = `xlColumnClustered`, `-4108` = `xlCenter`).
- Fechamento: os scripts tentam fechar workbooks sem salvar por padrão.

Boa prática: quando for adaptar para produção, use `try/finally` e desligue `ScreenUpdating`, `EnableEvents` e `Calculation` durante operações pesadas.
