
# -*- coding: utf-8 -*-
"""
Exercício 89: Validação e hyperlinks #89

Pré-requisitos:
- Windows + Microsoft Excel instalado
- Python + pywin32 (pip install pywin32)

Dica: execute com "python arquivo.py".
"""
import time
import sys
import win32com.client as win32


def main():
    excel = None
    try:
        excel = win32.Dispatch("Excel.Application")
        excel.Visible = True
        # Aceleração opcional em alguns exercícios
        # excel.ScreenUpdating = False
        # excel.DisplayAlerts = False

        # === INÍCIO DO EXERCÍCIO ===

wb = excel.Workbooks.Add()
ws = wb.Worksheets(1)
ws.Range('A1').Value = 'Escolha:'
ws.Range('B1').Value = 'Opções'
ws.Range('B2:B4').Value = [["Alfa"],["Beta"],["Gama"]]
val = ws.Range('A2').Validation
val.Delete()
val.Add(Type=3, AlertStyle=1, Operator=1, Formula1='=$B$2:$B$4')  # xlValidateList

        # === FIM DO EXERCÍCIO ===

        # Pequena pausa para ver o resultado ao rodar individualmente
        time.sleep(1)
    finally:
        if excel is not None:
            try:
                # Não salvar por padrão; cada exercício ajusta conforme necessário
                for wb in list(excel.Workbooks):
                    try:
                        wb.Close(SaveChanges=False)
                    except Exception:
                        pass
            except Exception:
                pass
            excel.Quit()


if __name__ == '__main__':
    main()
