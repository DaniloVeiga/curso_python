
# -*- coding: utf-8 -*-
"""
Exercício 1: Iniciar Excel e torná-lo visível

Pré-requisitos:
- Windows + Microsoft Excel instalado
- Python + pywin32 (pip install pywin32)

Dica: execute com "python arquivo.py".
"""
import time
import sys
import win32com.client as win32


def main():
    excel = None
    try:
        excel = win32.Dispatch("Excel.Application")
        excel.Visible = True
        # Aceleração opcional em alguns exercícios
        # excel.ScreenUpdating = False
        # excel.DisplayAlerts = False

        # === INÍCIO DO EXERCÍCIO ===
        wb = excel.Workbooks.Add()
        ws = wb.Worksheets(1)
        ws.Range('A1').Value = 'Excel visível via COM'

        # === FIM DO EXERCÍCIO ===

        # Pequena pausa para ver o resultado ao rodar individualmente
        time.sleep(1)
    finally:
        if excel is not None:
            try:
                # Não salvar por padrão; cada exercício ajusta conforme necessário
                for wb in list(excel.Workbooks):
                    try:
                        wb.Close(SaveChanges=False)
                    except Exception:
                        pass
            except Exception:
                pass
            excel.Quit()


if __name__ == '__main__':
    main()
