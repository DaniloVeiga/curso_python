
# -*- coding: utf-8 -*-
"""
Exercício 54: Células e formatação #54

Pré-requisitos:
- Windows + Microsoft Excel instalado
- Python + pywin32 (pip install pywin32)

Dica: execute com "python arquivo.py".
"""
import time
import sys
import win32com.client as win32


def main():
    excel = None
    try:
        excel = win32.Dispatch("Excel.Application")
        excel.Visible = True
        # Aceleração opcional em alguns exercícios
        # excel.ScreenUpdating = False
        # excel.DisplayAlerts = False

        # === INÍCIO DO EXERCÍCIO ===

wb = excel.Workbooks.Add()
ws = wb.Worksheets(1)
ws.Range('A1:C1').Value = [["Produto","Qtd","Preço"]]
ws.Range('A2:C6').Value = [["A",10,5.5],["B",7,6.2],["C",11,4.9],["D",2,10.0],["E",14,3.2]]
ws.Range('A1:C1').Font.Bold = True
ws.Range('A1:C1').Interior.Color = 0x00FFFF  # amarelo (BGR)
ws.Columns('A:C').AutoFit()

        # === FIM DO EXERCÍCIO ===

        # Pequena pausa para ver o resultado ao rodar individualmente
        time.sleep(1)
    finally:
        if excel is not None:
            try:
                # Não salvar por padrão; cada exercício ajusta conforme necessário
                for wb in list(excel.Workbooks):
                    try:
                        wb.Close(SaveChanges=False)
                    except Exception:
                        pass
            except Exception:
                pass
            excel.Quit()


if __name__ == '__main__':
    main()
