# Exemplo 8674: np.stack para criar eixo extra
# Objetivo: Empilhar arrays ao longo de um novo eixo.
import numpy as np

x = np.arange(4)
y = x + 12
S = np.stack([x, y], axis=0)
print("S.shape:", S.shape)
