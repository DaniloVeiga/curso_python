# Exemplo 1281: np.pad em 2D
# Objetivo: Preencher bordas de uma matriz com constante.
import numpy as np

A = np.arange(4*3).reshape(4, 3)
P = np.pad(A, pad_width=2, mode='constant', constant_values=-1)
print("P.shape:", P.shape)
