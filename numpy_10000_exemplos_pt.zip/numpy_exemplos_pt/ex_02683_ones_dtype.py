# Exemplo 2683: np.ones com dtype=int e forma (6,5)
# Objetivo: Criar matriz de uns com tipo inteiro.
import numpy as np

O = np.ones((6, 5), dtype=int)
print("O =
", O)
print("dtype:", O.dtype)
