# Exemplo 4493: np.einsum para multiplicação matriz-vetor
# Objetivo: Usar einsum em operação equivalente a A@x.
import numpy as np

A = np.arange(6*3).reshape(6, 3)
x = np.arange(3)
y = np.einsum('ij,j->i', A, x)
print("y:", y)
