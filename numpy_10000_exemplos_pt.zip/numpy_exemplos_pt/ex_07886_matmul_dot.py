# Exemplo 7886: Produto matricial (matmul / dot)
# Objetivo: Multiplicar matrizes 2D.
import numpy as np

A = np.arange(4*4).reshape(4, 4)
B = np.arange(4*4).reshape(4, 4)
C = A @ B
print("C.shape:", C.shape)
