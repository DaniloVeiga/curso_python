# Exemplo 5540: np.array_split para dividir vetor
# Objetivo: Dividir um vetor em partes quase iguais.
import numpy as np

x = np.arange(3*2)
parts = np.array_split(x, 2)
print([p.size for p in parts])
