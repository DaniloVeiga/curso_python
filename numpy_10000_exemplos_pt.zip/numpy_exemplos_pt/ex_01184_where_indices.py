# Exemplo 1184: np.where para obter índices verdadeiros
# Objetivo: Localizar índices que satisfazem uma condição.
import numpy as np

x = np.arange(7*2)
idx = np.where(x % 4 == 0)
print("idx:", idx)
