# Exemplo 5615: np.tile e np.repeat
# Objetivo: Repetir padrões em vetores.
import numpy as np

x = np.arange(5)
print("tile:", np.tile(x, 3))
print("repeat:", np.repeat(x, 4))
