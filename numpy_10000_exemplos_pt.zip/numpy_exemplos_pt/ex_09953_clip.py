# Exemplo 9953: np.clip
# Objetivo: Limitar valores a um intervalo [a, b].
import numpy as np

x = np.arange(-5, 6)
y = np.clip(x, -3, 3)
print("y:", y)
