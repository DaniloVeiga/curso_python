# Exemplo 8998: flatten vs ravel
# Objetivo: Comparar cópia (flatten) e view (ravel).
import numpy as np

A = np.arange(6*4).reshape(6, 4)
print("flatten len:", A.flatten().size)
print("ravel len:", A.ravel().size)
