# Exemplo 5975: np.einsum para multiplicação matriz-vetor
# Objetivo: Usar einsum em operação equivalente a A@x.
import numpy as np

A = np.arange(3*5).reshape(3, 5)
x = np.arange(5)
y = np.einsum('ij,j->i', A, x)
print("y:", y)
