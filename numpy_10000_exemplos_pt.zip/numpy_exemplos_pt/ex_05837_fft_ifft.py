# Exemplo 5837: Transformada Rápida de Fourier (FFT)
# Objetivo: Calcular FFT simples e sua inversa.
import numpy as np

x = np.sin(np.linspace(0, 2*np.pi, 5*3, endpoint=False))
X = np.fft.fft(x)
x_rec = np.fft.ifft(X)
print("erro de reconstrução:", float(np.abs(x - x_rec).max()))
