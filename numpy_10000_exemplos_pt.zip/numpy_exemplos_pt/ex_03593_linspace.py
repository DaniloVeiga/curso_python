# Exemplo 3593: Pontos igualmente espaçados com np.linspace(0.7, 3.6, 7)
# Objetivo: Criar pontos igualmente espaçados em um intervalo contínuo.
import numpy as np

x = np.linspace(0.7, 3.6, 7)
print("x =", x)
print("espaçamento médio:", (x[-1]-x[0])/(x.size-1))
