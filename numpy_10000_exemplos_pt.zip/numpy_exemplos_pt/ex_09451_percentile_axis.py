# Exemplo 9451: np.percentile ao longo de eixo
# Objetivo: Percentil por coluna.
import numpy as np

A = np.arange(4*5).reshape(4, 5)
print("p50 por coluna:", np.percentile(A, 50, axis=0))
