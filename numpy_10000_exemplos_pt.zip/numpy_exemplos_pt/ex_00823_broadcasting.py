# Exemplo 823: Broadcasting entre formas compatíveis
# Objetivo: Somar vetor (1x5) a matriz (6x5).
import numpy as np

A = np.arange(6*5).reshape(6, 5)
v = np.arange(5)
B = A + v
print("B.shape:", B.shape)
