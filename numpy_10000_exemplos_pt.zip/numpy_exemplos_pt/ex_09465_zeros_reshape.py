# Exemplo 9465: np.zeros e reshape para matriz 3x3
# Objetivo: Criar uma matriz de zeros e remodelar para 2D.
import numpy as np

z = np.zeros(3*3)
Z = z.reshape(3, 3)
print("Z =
", Z)
print("shape:", Z.shape)
