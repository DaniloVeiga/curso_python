# Exemplo 1363: % de variação com np.diff
# Objetivo: Calcular % de variação entre elementos consecutivos.
import numpy as np

x = np.linspace(1, 14, 6*5)
ret = np.diff(x) / x[:-1]
print("ret[0:5] =", ret[:5])
