# Exemplo 4220: Pontos igualmente espaçados com np.linspace(1.0, 2.8, 11)
# Objetivo: Criar pontos igualmente espaçados em um intervalo contínuo.
import numpy as np

x = np.linspace(1.0, 2.8, 11)
print("x =", x)
print("espaçamento médio:", (x[-1]-x[0])/(x.size-1))
