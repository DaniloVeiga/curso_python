# Exemplo 9544: Broadcasting entre formas compatíveis
# Objetivo: Somar vetor (1x2) a matriz (7x2).
import numpy as np

A = np.arange(7*2).reshape(7, 2)
v = np.arange(2)
B = A + v
print("B.shape:", B.shape)
