# Exemplo 6152: np.any e np.all
# Objetivo: Avaliar condições booleanas agregadas.
import numpy as np

x = np.arange(5*2)
print("algum > 10?", np.any(x > 10))
print("todos < 22?", np.all(x < 22))
