# Exemplo 3513: Amostragem com np.random.Generator.choice
# Objetivo: Amostrar sem reposição.
import numpy as np

rng = np.random.default_rng(4747)
base = np.arange(20)
amostra = rng.choice(base, size=2, replace=False)
print("amostra:", amostra)
