# Exemplo 9447: np.concatenate em axis=1
# Objetivo: Concatenar matrizes horizontalmente.
import numpy as np

A = np.arange(5*5).reshape(5, 5)
B = np.arange(5*2).reshape(5, 2)
C = np.concatenate([A, B], axis=1)
print("C.shape:", C.shape)
