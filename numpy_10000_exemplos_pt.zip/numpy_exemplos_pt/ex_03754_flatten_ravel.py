# Exemplo 3754: flatten vs ravel
# Objetivo: Comparar cópia (flatten) e view (ravel).
import numpy as np

A = np.arange(7*4).reshape(7, 4)
print("flatten len:", A.flatten().size)
print("ravel len:", A.ravel().size)
