# Exemplo 3413: np.hstack e np.vstack
# Objetivo: Empilhar horizontalmente e verticalmente.
import numpy as np

x = np.arange(3)
y = x + 7
print("hstack:", np.hstack([x, y]))
print("vstack shape:", np.vstack([x, y]).shape)
