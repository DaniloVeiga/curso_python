# Exemplo 3925: flatten vs ravel
# Objetivo: Comparar cópia (flatten) e view (ravel).
import numpy as np

A = np.arange(3*3).reshape(3, 3)
print("flatten len:", A.flatten().size)
print("ravel len:", A.ravel().size)
