# Exemplo 9556: np.random.Generator.permutation
# Objetivo: Permutar elementos aleatoriamente.
import numpy as np

rng = np.random.default_rng(10790)
perm = rng.permutation(np.arange(4*2))
print("perm[0:10]:", perm[:10])
