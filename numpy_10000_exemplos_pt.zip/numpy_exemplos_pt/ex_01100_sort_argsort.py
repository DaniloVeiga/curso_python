# Exemplo 1100: np.sort e np.argsort
# Objetivo: Ordenar valores e obter índices de ordenação.
import numpy as np

rng = np.random.default_rng(2334)
x = rng.integers(0, 100, size=3*2)
print("x ordenado:", np.sort(x))
print("índices ordenação:", np.argsort(x))
