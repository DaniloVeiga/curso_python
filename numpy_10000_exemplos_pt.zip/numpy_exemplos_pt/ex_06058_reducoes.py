# Exemplo 6058: Reduções: sum e mean por eixo
# Objetivo: Calcular somas e médias por eixo.
import numpy as np

A = np.arange(6*4).reshape(6, 4)
print("sum axis=0:", A.sum(axis=0))
print("mean axis=1:", A.mean(axis=1))
