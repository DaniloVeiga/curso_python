# Exemplo 2523: Ufuncs: np.sin e np.cos
# Objetivo: Aplicar funções element-wise em um grid.
import numpy as np

t = np.linspace(0, np.pi, 6*5)
val = np.sin(t) + np.cos(t)
print("val[0:5] =", val[:5])
