# Exemplo 6216: np.zeros e reshape para matriz 4x2
# Objetivo: Criar uma matriz de zeros e remodelar para 2D.
import numpy as np

z = np.zeros(4*2)
Z = z.reshape(4, 2)
print("Z =
", Z)
print("shape:", Z.shape)
