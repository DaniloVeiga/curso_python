# Exemplo 386: np.where para obter índices verdadeiros
# Objetivo: Localizar índices que satisfazem uma condição.
import numpy as np

x = np.arange(4*4)
idx = np.where(x % 4 == 0)
print("idx:", idx)
