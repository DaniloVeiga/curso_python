# Exemplo 3753: np.gradient em matriz 2D
# Objetivo: Gradiente por eixo em 2D.
import numpy as np

A = np.arange(6*3, dtype=float).reshape(6, 3)
gx, gy = np.gradient(A)
print("gx.shape, gy.shape:", gx.shape, gy.shape)
