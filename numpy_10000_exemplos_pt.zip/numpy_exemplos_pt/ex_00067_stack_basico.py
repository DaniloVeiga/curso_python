# Exemplo 67: np.stack para criar eixo extra
# Objetivo: Empilhar arrays ao longo de um novo eixo.
import numpy as np

x = np.arange(5)
y = x + 9
S = np.stack([x, y], axis=0)
print("S.shape:", S.shape)
