# Exemplo 6404: Produto matricial (matmul / dot)
# Objetivo: Multiplicar matrizes 2D.
import numpy as np

A = np.arange(7*2).reshape(7, 2)
B = np.arange(2*4).reshape(2, 4)
C = A @ B
print("C.shape:", C.shape)
