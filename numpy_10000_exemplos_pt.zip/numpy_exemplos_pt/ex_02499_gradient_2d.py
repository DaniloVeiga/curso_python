# Exemplo 2499: np.gradient em matriz 2D
# Objetivo: Gradiente por eixo em 2D.
import numpy as np

A = np.arange(7*5, dtype=float).reshape(7, 5)
gx, gy = np.gradient(A)
print("gx.shape, gy.shape:", gx.shape, gy.shape)
