# Exemplo 4029: np.searchsorted
# Objetivo: Encontrar posições de inserção em array ordenado.
import numpy as np

x = np.array([1,3,5,7,9])
pos = np.searchsorted(x, [1, 4])
print("posições:", pos)
