# Exemplo 9712: Decomposição SVD
# Objetivo: Calcular SVD de uma matriz retangular.
import numpy as np

A = np.arange(5*2, dtype=float).reshape(5, 2)
U, s, Vt = np.linalg.svd(A, full_matrices=False)
print("rank aprox:", (s > 1e-9).sum())
