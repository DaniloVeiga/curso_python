# Exemplo 5149: np.histogram
# Objetivo: Calcular histograma de dados.
import numpy as np

rng = np.random.default_rng(6383)
x = rng.normal(size=100)
h, edges = np.histogram(x, bins=9)
print("h:", h)
print("edges:", edges)
