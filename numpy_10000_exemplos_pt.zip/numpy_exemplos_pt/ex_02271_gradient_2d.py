# Exemplo 2271: np.gradient em matriz 2D
# Objetivo: Gradiente por eixo em 2D.
import numpy as np

A = np.arange(4*5, dtype=float).reshape(4, 5)
gx, gy = np.gradient(A)
print("gx.shape, gy.shape:", gx.shape, gy.shape)
