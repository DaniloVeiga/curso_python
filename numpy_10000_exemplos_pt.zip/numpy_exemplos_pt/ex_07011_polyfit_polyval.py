# Exemplo 7011: Ajuste polinomial com np.polyfit / np.polyval
# Objetivo: Ajustar polinômio e avaliar em novos pontos.
import numpy as np

x = np.linspace(0, 1, 4*5)
y = 2*x + 0.5 + 0.01*np.sin(10*x)
coef = np.polyfit(x, y, deg=2)
y2 = np.polyval(coef, x)
print("coef:", coef)
print("erro médio:", float(np.mean(np.abs(y2 - y))))
