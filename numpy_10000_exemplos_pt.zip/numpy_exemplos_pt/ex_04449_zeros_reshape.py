# Exemplo 4449: np.zeros e reshape para matriz 7x3
# Objetivo: Criar uma matriz de zeros e remodelar para 2D.
import numpy as np

z = np.zeros(7*3)
Z = z.reshape(7, 3)
print("Z =
", Z)
print("shape:", Z.shape)
