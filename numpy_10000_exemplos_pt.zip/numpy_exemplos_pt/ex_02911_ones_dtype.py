# Exemplo 2911: np.ones com dtype=int e forma (4,5)
# Objetivo: Criar matriz de uns com tipo inteiro.
import numpy as np

O = np.ones((4, 5), dtype=int)
print("O =
", O)
print("dtype:", O.dtype)
