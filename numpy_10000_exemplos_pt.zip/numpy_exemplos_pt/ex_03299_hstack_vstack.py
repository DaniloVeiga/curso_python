# Exemplo 3299: np.hstack e np.vstack
# Objetivo: Empilhar horizontalmente e verticalmente.
import numpy as np

x = np.arange(5)
y = x + 13
print("hstack:", np.hstack([x, y]))
print("vstack shape:", np.vstack([x, y]).shape)
