# Exemplo 1063: np.random.Generator.permutation
# Objetivo: Permutar elementos aleatoriamente.
import numpy as np

rng = np.random.default_rng(2297)
perm = rng.permutation(np.arange(6*5))
print("perm[0:10]:", perm[:10])
