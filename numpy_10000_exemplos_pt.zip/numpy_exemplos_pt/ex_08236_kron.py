# Exemplo 8236: Produto de Kronecker (np.kron)
# Objetivo: Expandir matrizes via produto de Kronecker.
import numpy as np

A = np.arange(4).reshape(4, 1)
B = np.ones((2, 3))
K = np.kron(A, B)
print("K.shape:", K.shape)
