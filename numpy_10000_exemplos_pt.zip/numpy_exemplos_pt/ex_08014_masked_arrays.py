# Exemplo 8014: np.ma para mascarar valores
# Objetivo: Mascarar valores negativos.
import numpy as np

x = np.array([-1, 0, 1, -2, 3])
mx = np.ma.masked_less(x, 0)
print("mascarado:", mx)
