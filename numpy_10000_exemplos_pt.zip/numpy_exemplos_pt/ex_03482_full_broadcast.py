# Exemplo 3482: np.full e broadcast em soma escalar
# Objetivo: Preencher matriz com valor fixo e somar escalar (broadcasting).
import numpy as np

A = np.full((5, 4), 4, dtype=float)
B = A + 10  # broadcasting do escalar
print("A =
", A)
print("B = A + 10 =
", B)
