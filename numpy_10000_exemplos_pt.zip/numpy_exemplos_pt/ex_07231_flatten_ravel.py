# Exemplo 7231: flatten vs ravel
# Objetivo: Comparar cópia (flatten) e view (ravel).
import numpy as np

A = np.arange(4*5).reshape(4, 5)
print("flatten len:", A.flatten().size)
print("ravel len:", A.ravel().size)
