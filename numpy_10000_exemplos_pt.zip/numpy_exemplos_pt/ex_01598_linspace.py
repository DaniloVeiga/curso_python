# Exemplo 1598: Pontos igualmente espaçados com np.linspace(0.4, 2.0, 7)
# Objetivo: Criar pontos igualmente espaçados em um intervalo contínuo.
import numpy as np

x = np.linspace(0.4, 2.0, 7)
print("x =", x)
print("espaçamento médio:", (x[-1]-x[0])/(x.size-1))
