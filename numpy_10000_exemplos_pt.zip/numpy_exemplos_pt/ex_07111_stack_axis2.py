# Exemplo 7111: np.stack no eixo 2
# Objetivo: Criar eixo de "camadas" (depth).
import numpy as np

A = np.arange(4*5).reshape(4, 5)
B = A + 9
C = np.stack([A, B], axis=2)
print("C.shape:", C.shape)
