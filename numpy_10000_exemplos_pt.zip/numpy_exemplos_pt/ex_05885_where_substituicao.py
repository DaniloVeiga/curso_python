# Exemplo 5885: np.where para substituição condicional
# Objetivo: Substituir valores baseado em condição.
import numpy as np

x = np.arange(3*3)
y = np.where(x % 2 == 0, x, -1)
print("y =", y)
