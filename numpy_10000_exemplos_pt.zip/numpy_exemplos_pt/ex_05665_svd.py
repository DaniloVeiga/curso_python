# Exemplo 5665: Decomposição SVD
# Objetivo: Calcular SVD de uma matriz retangular.
import numpy as np

A = np.arange(3*3, dtype=float).reshape(3, 3)
U, s, Vt = np.linalg.svd(A, full_matrices=False)
print("rank aprox:", (s > 1e-9).sum())
