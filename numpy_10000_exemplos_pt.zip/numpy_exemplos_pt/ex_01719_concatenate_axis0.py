# Exemplo 1719: np.concatenate em axis=0
# Objetivo: Concatenar duas matrizes verticalmente.
import numpy as np

A = np.arange(7*5).reshape(7, 5)
B = np.arange(7*5, 7*5*2).reshape(7, 5)
C = np.concatenate([A, B], axis=0)
print("C.shape:", C.shape)
