# Exemplo 1152: Máscara booleana para filtragem
# Objetivo: Selecionar elementos maiores que um limiar.
import numpy as np

x = np.arange(5*2)
mask = x > 3
print("selecionados:", x[mask])
