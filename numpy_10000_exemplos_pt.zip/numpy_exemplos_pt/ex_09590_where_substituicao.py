# Exemplo 9590: np.where para substituição condicional
# Objetivo: Substituir valores baseado em condição.
import numpy as np

x = np.arange(3*4)
y = np.where(x % 2 == 0, x, -1)
print("y =", y)
