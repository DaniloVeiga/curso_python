# Exemplo 427: Produto de Kronecker (np.kron)
# Objetivo: Expandir matrizes via produto de Kronecker.
import numpy as np

A = np.arange(5).reshape(5, 1)
B = np.ones((5, 3))
K = np.kron(A, B)
print("K.shape:", K.shape)
