# Exemplo 1143: np.zeros e reshape para matriz 6x5
# Objetivo: Criar uma matriz de zeros e remodelar para 2D.
import numpy as np

z = np.zeros(6*5)
Z = z.reshape(6, 5)
print("Z =
", Z)
print("shape:", Z.shape)
