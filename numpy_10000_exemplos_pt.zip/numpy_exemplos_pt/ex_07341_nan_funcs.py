# Exemplo 7341: Funções com NaN: np.nanmean e np.nanmax
# Objetivo: Ignorar NaNs ao agregar.
import numpy as np

x = np.array([1.0, np.nan, 2.0, 3.0])
print("nanmean:", np.nanmean(x))
print("nanmax:", np.nanmax(x))
