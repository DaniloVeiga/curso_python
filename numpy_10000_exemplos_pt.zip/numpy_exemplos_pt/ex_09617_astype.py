# Exemplo 9617: Conversão de tipo com astype
# Objetivo: Converter floats para inteiros.
import numpy as np

x = np.linspace(0, 1, 5*3)
y = (x*10).astype(int)
print("y:", y)
