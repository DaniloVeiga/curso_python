# Exemplo 3901: Broadcasting entre formas compatíveis
# Objetivo: Somar vetor (1x3) a matriz (4x3).
import numpy as np

A = np.arange(4*3).reshape(4, 3)
v = np.arange(3)
B = A + v
print("B.shape:", B.shape)
