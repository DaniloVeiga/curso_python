# Exemplo 2399: np.full e broadcast em soma escalar
# Objetivo: Preencher matriz com valor fixo e somar escalar (broadcasting).
import numpy as np

A = np.full((7, 5), 13, dtype=float)
B = A + 9  # broadcasting do escalar
print("A =
", A)
print("B = A + 9 =
", B)
