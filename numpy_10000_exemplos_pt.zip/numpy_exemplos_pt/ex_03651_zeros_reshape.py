# Exemplo 3651: np.zeros e reshape para matriz 4x5
# Objetivo: Criar uma matriz de zeros e remodelar para 2D.
import numpy as np

z = np.zeros(4*5)
Z = z.reshape(4, 5)
print("Z =
", Z)
print("shape:", Z.shape)
