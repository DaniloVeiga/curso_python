# Exemplo 3559: Broadcasting entre formas compatíveis
# Objetivo: Somar vetor (1x5) a matriz (7x5).
import numpy as np

A = np.arange(7*5).reshape(7, 5)
v = np.arange(5)
B = A + v
print("B.shape:", B.shape)
