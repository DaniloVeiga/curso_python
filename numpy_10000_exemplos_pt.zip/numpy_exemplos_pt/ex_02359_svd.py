# Exemplo 2359: Decomposição SVD
# Objetivo: Calcular SVD de uma matriz retangular.
import numpy as np

A = np.arange(7*5, dtype=float).reshape(7, 5)
U, s, Vt = np.linalg.svd(A, full_matrices=False)
print("rank aprox:", (s > 1e-9).sum())
