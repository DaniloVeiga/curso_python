# Exemplo 8330: reshape e transpose
# Objetivo: Remodelar vetor em matriz e transpor.
import numpy as np

v = np.arange(3*4)
A = v.reshape(3, 4)
AT = A.T
print("A =
", A)
print("A.T =
", AT)
