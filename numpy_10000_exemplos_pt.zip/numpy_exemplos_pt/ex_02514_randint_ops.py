# Exemplo 2514: np.random.default_rng().integers e operações básicas
# Objetivo: Gerar inteiros aleatórios e aplicar operações vetor/matriz.
import numpy as np

rng = np.random.default_rng(3748)
A = rng.integers(low=0, high=14, size=(7, 4))
B = rng.integers(low=0, high=14, size=(7, 4))
print("A =
", A)
print("B =
", B)
print("A + B =
", A + B)
print("A * B =
", A * B)
