# Exemplo 7589: reshape e transpose
# Objetivo: Remodelar vetor em matriz e transpor.
import numpy as np

v = np.arange(7*3)
A = v.reshape(7, 3)
AT = A.T
print("A =
", A)
print("A.T =
", AT)
