# Exemplo 94: np.random.Generator.permutation
# Objetivo: Permutar elementos aleatoriamente.
import numpy as np

rng = np.random.default_rng(1328)
perm = rng.permutation(np.arange(7*4))
print("perm[0:10]:", perm[:10])
