# Exemplo 3372: np.concatenate em axis=0
# Objetivo: Concatenar duas matrizes verticalmente.
import numpy as np

A = np.arange(5*2).reshape(5, 2)
B = np.arange(5*2, 5*2*2).reshape(5, 2)
C = np.concatenate([A, B], axis=0)
print("C.shape:", C.shape)
