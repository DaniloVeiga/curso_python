# Exemplo 3939: np.random.default_rng().integers e operações básicas
# Objetivo: Gerar inteiros aleatórios e aplicar operações vetor/matriz.
import numpy as np

rng = np.random.default_rng(5173)
A = rng.integers(low=0, high=19, size=(7, 5))
B = rng.integers(low=0, high=19, size=(7, 5))
print("A =
", A)
print("B =
", B)
print("A + B =
", A + B)
print("A * B =
", A * B)
