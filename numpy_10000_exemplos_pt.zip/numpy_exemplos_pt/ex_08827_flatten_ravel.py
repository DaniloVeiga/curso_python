# Exemplo 8827: flatten vs ravel
# Objetivo: Comparar cópia (flatten) e view (ravel).
import numpy as np

A = np.arange(5*5).reshape(5, 5)
print("flatten len:", A.flatten().size)
print("ravel len:", A.ravel().size)
