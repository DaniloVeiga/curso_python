# Exemplo 6672: np.zeros e reshape para matriz 5x2
# Objetivo: Criar uma matriz de zeros e remodelar para 2D.
import numpy as np

z = np.zeros(5*2)
Z = z.reshape(5, 2)
print("Z =
", Z)
print("shape:", Z.shape)
