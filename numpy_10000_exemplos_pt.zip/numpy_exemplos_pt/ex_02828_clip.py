# Exemplo 2828: np.clip
# Objetivo: Limitar valores a um intervalo [a, b].
import numpy as np

x = np.arange(-5, 6)
y = np.clip(x, -2, 4)
print("y:", y)
