# Exemplo 5726: np.diff e np.gradient
# Objetivo: Aproximar derivadas discretas.
import numpy as np

x = np.linspace(0, 1, 4*4)
y = x**2
print("diff:", np.diff(y)[:5])
print("gradient:", np.gradient(y)[:5])
