# Exemplo 4535: Datas com np.datetime64
# Objetivo: Criar sequência de datas diárias.
import numpy as np

start = np.datetime64('2020-01-01')
days = np.arange(3*5)
dates = start + days
print("primeiras datas:", dates[:5])
