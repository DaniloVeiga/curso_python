# Exemplo 6038: np.any e np.all
# Objetivo: Avaliar condições booleanas agregadas.
import numpy as np

x = np.arange(6*4)
print("algum > 4?", np.any(x > 4))
print("todos < 14?", np.all(x < 14))
