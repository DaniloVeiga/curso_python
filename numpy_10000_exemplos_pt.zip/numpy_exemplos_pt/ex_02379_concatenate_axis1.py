# Exemplo 2379: np.concatenate em axis=1
# Objetivo: Concatenar matrizes horizontalmente.
import numpy as np

A = np.arange(7*5).reshape(7, 5)
B = np.arange(7*2).reshape(7, 2)
C = np.concatenate([A, B], axis=1)
print("C.shape:", C.shape)
