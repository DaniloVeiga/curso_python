# Exemplo 3213: Resolver sistema linear com np.linalg.solve
# Objetivo: Resolver Ax=b para matriz quadrada pequena.
import numpy as np

A = np.eye(2) * 2 + np.ones((2, 2)) * 0.5
b = np.arange(1, 2+1)
x = np.linalg.solve(A, b)
print("x =", x)
