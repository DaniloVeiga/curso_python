# Exemplo 3868: flatten vs ravel
# Objetivo: Comparar cópia (flatten) e view (ravel).
import numpy as np

A = np.arange(6*2).reshape(6, 2)
print("flatten len:", A.flatten().size)
print("ravel len:", A.ravel().size)
