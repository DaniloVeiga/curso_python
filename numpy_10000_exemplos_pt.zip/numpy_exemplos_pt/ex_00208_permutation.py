# Exemplo 208: np.random.Generator.permutation
# Objetivo: Permutar elementos aleatoriamente.
import numpy as np

rng = np.random.default_rng(1442)
perm = rng.permutation(np.arange(6*2))
print("perm[0:10]:", perm[:10])
