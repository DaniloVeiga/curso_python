# Exemplo 176: np.full e broadcast em soma escalar
# Objetivo: Preencher matriz com valor fixo e somar escalar (broadcasting).
import numpy as np

A = np.full((4, 2), 10, dtype=float)
B = A + 12  # broadcasting do escalar
print("A =
", A)
print("B = A + 12 =
", B)
