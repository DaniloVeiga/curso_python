# Exemplo 1360: flatten vs ravel
# Objetivo: Comparar cópia (flatten) e view (ravel).
import numpy as np

A = np.arange(3*2).reshape(3, 2)
print("flatten len:", A.flatten().size)
print("ravel len:", A.ravel().size)
