# Exemplo 3286: np.random.Generator.permutation
# Objetivo: Permutar elementos aleatoriamente.
import numpy as np

rng = np.random.default_rng(4520)
perm = rng.permutation(np.arange(4*4))
print("perm[0:10]:", perm[:10])
