# Exemplo 6450: np.concatenate em axis=0
# Objetivo: Concatenar duas matrizes verticalmente.
import numpy as np

A = np.arange(3*4).reshape(3, 4)
B = np.arange(3*4, 3*4*2).reshape(3, 4)
C = np.concatenate([A, B], axis=0)
print("C.shape:", C.shape)
