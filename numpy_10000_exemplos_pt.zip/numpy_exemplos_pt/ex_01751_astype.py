# Exemplo 1751: Conversão de tipo com astype
# Objetivo: Converter floats para inteiros.
import numpy as np

x = np.linspace(0, 1, 4*5)
y = (x*10).astype(int)
print("y:", y)
