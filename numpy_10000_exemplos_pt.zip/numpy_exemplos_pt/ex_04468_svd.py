# Exemplo 4468: Decomposição SVD
# Objetivo: Calcular SVD de uma matriz retangular.
import numpy as np

A = np.arange(6*2, dtype=float).reshape(6, 2)
U, s, Vt = np.linalg.svd(A, full_matrices=False)
print("rank aprox:", (s > 1e-9).sum())
