# Exemplo 9757: np.stack para criar eixo extra
# Objetivo: Empilhar arrays ao longo de um novo eixo.
import numpy as np

x = np.arange(3)
y = x + 3
S = np.stack([x, y], axis=0)
print("S.shape:", S.shape)
