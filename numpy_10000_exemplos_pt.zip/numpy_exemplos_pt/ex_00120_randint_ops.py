# Exemplo 120: np.random.default_rng().integers e operações básicas
# Objetivo: Gerar inteiros aleatórios e aplicar operações vetor/matriz.
import numpy as np

rng = np.random.default_rng(1354)
A = rng.integers(low=0, high=10, size=(3, 2))
B = rng.integers(low=0, high=10, size=(3, 2))
print("A =
", A)
print("B =
", B)
print("A + B =
", A + B)
print("A * B =
", A * B)
