# Exemplo 6370: np.stack no eixo 2
# Objetivo: Criar eixo de "camadas" (depth).
import numpy as np

A = np.arange(3*4).reshape(3, 4)
B = A + 12
C = np.stack([A, B], axis=2)
print("C.shape:", C.shape)
