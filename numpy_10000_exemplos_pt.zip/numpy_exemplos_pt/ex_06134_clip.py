# Exemplo 6134: np.clip
# Objetivo: Limitar valores a um intervalo [a, b].
import numpy as np

x = np.arange(-5, 6)
y = np.clip(x, 0, 2)
print("y:", y)
