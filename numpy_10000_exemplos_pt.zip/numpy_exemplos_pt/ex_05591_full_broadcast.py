# Exemplo 5591: np.full e broadcast em soma escalar
# Objetivo: Preencher matriz com valor fixo e somar escalar (broadcasting).
import numpy as np

A = np.full((4, 5), 13, dtype=float)
B = A + 5  # broadcasting do escalar
print("A =
", A)
print("B = A + 5 =
", B)
