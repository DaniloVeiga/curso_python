# Exemplo 1351: np.apply_along_axis
# Objetivo: Aplicar função customizada ao longo de um eixo.
import numpy as np

A = np.arange(4*5).reshape(4, 5)
fn = lambda v: v.max() - v.min()
res = np.apply_along_axis(fn, axis=1, arr=A)
print("res:", res)
