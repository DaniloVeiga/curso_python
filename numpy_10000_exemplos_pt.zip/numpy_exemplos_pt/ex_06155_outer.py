# Exemplo 6155: Produto externo com np.outer
# Objetivo: Gerar matriz como produto externo de vetores.
import numpy as np

x = np.arange(3)
y = np.arange(5)
A = np.outer(x, y)
print("A.shape:", A.shape)
