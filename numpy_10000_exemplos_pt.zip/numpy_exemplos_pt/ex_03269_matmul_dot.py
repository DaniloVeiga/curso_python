# Exemplo 3269: Produto matricial (matmul / dot)
# Objetivo: Multiplicar matrizes 2D.
import numpy as np

A = np.arange(7*3).reshape(7, 3)
B = np.arange(3*4).reshape(3, 4)
C = A @ B
print("C.shape:", C.shape)
