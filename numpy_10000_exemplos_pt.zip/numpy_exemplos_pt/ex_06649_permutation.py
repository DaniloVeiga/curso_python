# Exemplo 6649: np.random.Generator.permutation
# Objetivo: Permutar elementos aleatoriamente.
import numpy as np

rng = np.random.default_rng(7883)
perm = rng.permutation(np.arange(7*3))
print("perm[0:10]:", perm[:10])
