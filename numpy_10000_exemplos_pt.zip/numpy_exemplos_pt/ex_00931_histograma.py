# Exemplo 931: np.histogram
# Objetivo: Calcular histograma de dados.
import numpy as np

rng = np.random.default_rng(2165)
x = rng.normal(size=100)
h, edges = np.histogram(x, bins=6)
print("h:", h)
print("edges:", edges)
