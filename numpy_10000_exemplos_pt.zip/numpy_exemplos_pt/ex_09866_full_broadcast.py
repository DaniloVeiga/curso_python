# Exemplo 9866: np.full e broadcast em soma escalar
# Objetivo: Preencher matriz com valor fixo e somar escalar (broadcasting).
import numpy as np

A = np.full((4, 4), 4, dtype=float)
B = A + 2  # broadcasting do escalar
print("A =
", A)
print("B = A + 2 =
", B)
