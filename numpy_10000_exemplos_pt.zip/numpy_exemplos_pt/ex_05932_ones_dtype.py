# Exemplo 5932: np.ones com dtype=int e forma (5,2)
# Objetivo: Criar matriz de uns com tipo inteiro.
import numpy as np

O = np.ones((5, 2), dtype=int)
print("O =
", O)
print("dtype:", O.dtype)
