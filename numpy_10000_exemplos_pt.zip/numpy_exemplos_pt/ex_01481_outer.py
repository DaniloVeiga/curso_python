# Exemplo 1481: Produto externo com np.outer
# Objetivo: Gerar matriz como produto externo de vetores.
import numpy as np

x = np.arange(4)
y = np.arange(3)
A = np.outer(x, y)
print("A.shape:", A.shape)
