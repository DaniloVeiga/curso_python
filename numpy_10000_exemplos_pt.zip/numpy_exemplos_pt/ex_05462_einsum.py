# Exemplo 5462: np.einsum para multiplicação matriz-vetor
# Objetivo: Usar einsum em operação equivalente a A@x.
import numpy as np

A = np.arange(5*4).reshape(5, 4)
x = np.arange(4)
y = np.einsum('ij,j->i', A, x)
print("y:", y)
