# Exemplo 9117: Acumuladas: cumsum e cumprod
# Objetivo: Somatório e produto acumulados.
import numpy as np

x = np.arange(1, 5*3+1)
print("cumsum[0:5] =", np.cumsum(x)[:5])
print("cumprod[0:5] =", np.cumprod(x)[:5])
