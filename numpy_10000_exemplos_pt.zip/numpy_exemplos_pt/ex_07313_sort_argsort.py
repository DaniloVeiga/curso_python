# Exemplo 7313: np.sort e np.argsort
# Objetivo: Ordenar valores e obter índices de ordenação.
import numpy as np

rng = np.random.default_rng(8547)
x = rng.integers(0, 100, size=6*3)
print("x ordenado:", np.sort(x))
print("índices ordenação:", np.argsort(x))
