# Exemplo 5255: np.array_split para dividir vetor
# Objetivo: Dividir um vetor em partes quase iguais.
import numpy as np

x = np.arange(3*5)
parts = np.array_split(x, 3)
print([p.size for p in parts])
