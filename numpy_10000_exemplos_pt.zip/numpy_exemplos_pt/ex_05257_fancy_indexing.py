# Exemplo 5257: Indexação avançada (fancy indexing)
# Objetivo: Indexar com lista de posições específicas.
import numpy as np

x = np.arange(20)
idxs = np.array([3, 5, 14])
print("x[idxs] =", x[idxs])
