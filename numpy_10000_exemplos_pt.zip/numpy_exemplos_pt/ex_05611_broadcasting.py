# Exemplo 5611: Broadcasting entre formas compatíveis
# Objetivo: Somar vetor (1x5) a matriz (4x5).
import numpy as np

A = np.arange(4*5).reshape(4, 5)
v = np.arange(5)
B = A + v
print("B.shape:", B.shape)
