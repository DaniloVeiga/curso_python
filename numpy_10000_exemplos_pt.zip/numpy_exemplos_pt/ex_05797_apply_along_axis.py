# Exemplo 5797: np.apply_along_axis
# Objetivo: Aplicar função customizada ao longo de um eixo.
import numpy as np

A = np.arange(5*3).reshape(5, 3)
fn = lambda v: v.max() - v.min()
res = np.apply_along_axis(fn, axis=1, arr=A)
print("res:", res)
