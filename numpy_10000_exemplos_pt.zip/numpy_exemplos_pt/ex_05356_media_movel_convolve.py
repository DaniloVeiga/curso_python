# Exemplo 5356: Média móvel com np.convolve
# Objetivo: Calcular média móvel simples usando convolução.
import numpy as np

x = np.arange(4*2, dtype=float)
k = 3
kernel = np.ones(k)/k
y = np.convolve(x, kernel, mode='valid')
print("len(y):", len(y))
