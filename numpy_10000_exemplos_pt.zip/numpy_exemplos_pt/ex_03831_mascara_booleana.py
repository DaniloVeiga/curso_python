# Exemplo 3831: Máscara booleana para filtragem
# Objetivo: Selecionar elementos maiores que um limiar.
import numpy as np

x = np.arange(4*5)
mask = x > 8
print("selecionados:", x[mask])
