# Exemplo 3356: np.hstack e np.vstack
# Objetivo: Empilhar horizontalmente e verticalmente.
import numpy as np

x = np.arange(2)
y = x + 10
print("hstack:", np.hstack([x, y]))
print("vstack shape:", np.vstack([x, y]).shape)
