# Exemplo 8551: Criação de array 1D com np.arange(9, 25, 1)
# Objetivo: Demonstrar a criação de sequências com intervalos regulares.
import numpy as np

a = np.arange(9, 25, 1)
print("a =", a)
print("tamanho:", a.size, "min:", a.min(), "max:", a.max())
