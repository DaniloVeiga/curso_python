# Exemplo 3828: np.concatenate em axis=0
# Objetivo: Concatenar duas matrizes verticalmente.
import numpy as np

A = np.arange(6*2).reshape(6, 2)
B = np.arange(6*2, 6*2*2).reshape(6, 2)
C = np.concatenate([A, B], axis=0)
print("C.shape:", C.shape)
