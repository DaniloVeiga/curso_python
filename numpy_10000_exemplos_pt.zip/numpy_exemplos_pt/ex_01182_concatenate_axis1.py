# Exemplo 1182: np.concatenate em axis=1
# Objetivo: Concatenar matrizes horizontalmente.
import numpy as np

A = np.arange(5*4).reshape(5, 4)
B = np.arange(5*2).reshape(5, 2)
C = np.concatenate([A, B], axis=1)
print("C.shape:", C.shape)
