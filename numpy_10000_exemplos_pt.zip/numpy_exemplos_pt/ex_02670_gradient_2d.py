# Exemplo 2670: np.gradient em matriz 2D
# Objetivo: Gradiente por eixo em 2D.
import numpy as np

A = np.arange(3*4, dtype=float).reshape(3, 4)
gx, gy = np.gradient(A)
print("gx.shape, gy.shape:", gx.shape, gy.shape)
