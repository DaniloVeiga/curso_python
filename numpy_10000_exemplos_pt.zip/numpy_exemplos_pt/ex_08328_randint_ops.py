# Exemplo 8328: np.random.default_rng().integers e operações básicas
# Objetivo: Gerar inteiros aleatórios e aplicar operações vetor/matriz.
import numpy as np

rng = np.random.default_rng(9562)
A = rng.integers(low=0, high=18, size=(6, 2))
B = rng.integers(low=0, high=18, size=(6, 2))
print("A =
", A)
print("B =
", B)
print("A + B =
", A + B)
print("A * B =
", A * B)
