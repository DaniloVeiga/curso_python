# Exemplo 4137: Array estruturado com dtypes compostos
# Objetivo: Usar dtype composto (nome, idade).
import numpy as np

dt = np.dtype([('nome', 'U10'), ('idade', 'i4')])
dados = np.array([('Ana', 30), ('Bia', 25)], dtype=dt)
print("idades:", dados['idade'])
