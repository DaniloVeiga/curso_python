# Exemplo 127: Indexação avançada (fancy indexing)
# Objetivo: Indexar com lista de posições específicas.
import numpy as np

x = np.arange(20)
idxs = np.array([9, 17, 5])
print("x[idxs] =", x[idxs])
