# Exemplo 3148: Indexação avançada (fancy indexing)
# Objetivo: Indexar com lista de posições específicas.
import numpy as np

x = np.arange(20)
idxs = np.array([6, 13, 0])
print("x[idxs] =", x[idxs])
