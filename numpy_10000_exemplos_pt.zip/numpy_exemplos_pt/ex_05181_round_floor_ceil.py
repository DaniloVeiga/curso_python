# Exemplo 5181: np.round, np.floor, np.ceil
# Objetivo: Arredondamentos diversos.
import numpy as np

x = np.linspace(-2, 2, 4*3)
print("round:", np.round(x)[:6])
print("floor:", np.floor(x)[:6])
print("ceil:", np.ceil(x)[:6])
