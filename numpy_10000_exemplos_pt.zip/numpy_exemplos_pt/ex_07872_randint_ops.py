# Exemplo 7872: np.random.default_rng().integers e operações básicas
# Objetivo: Gerar inteiros aleatórios e aplicar operações vetor/matriz.
import numpy as np

rng = np.random.default_rng(9106)
A = rng.integers(low=0, high=12, size=(5, 2))
B = rng.integers(low=0, high=12, size=(5, 2))
print("A =
", A)
print("B =
", B)
print("A + B =
", A + B)
print("A * B =
", A * B)
