# Exemplo 7987: Amostras normais e estatísticas (média/desvio)
# Objetivo: Amostrar valores de N(0,1) e calcular média e desvio padrão.
import numpy as np

rng = np.random.default_rng(9221)
X = rng.normal(loc=0.0, scale=1.0, size=(5, 5))
print("média:", X.mean(), "desvio padrão:", X.std())
print("média por coluna:", X.mean(axis=0))
