# Exemplo 8210: Pontos igualmente espaçados com np.linspace(0.4, 1.2, 11)
# Objetivo: Criar pontos igualmente espaçados em um intervalo contínuo.
import numpy as np

x = np.linspace(0.4, 1.2, 11)
print("x =", x)
print("espaçamento médio:", (x[-1]-x[0])/(x.size-1))
