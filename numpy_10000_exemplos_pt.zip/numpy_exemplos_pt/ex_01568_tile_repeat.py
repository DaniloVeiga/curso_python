# Exemplo 1568: np.tile e np.repeat
# Objetivo: Repetir padrões em vetores.
import numpy as np

x = np.arange(2)
print("tile:", np.tile(x, 6))
print("repeat:", np.repeat(x, 4))
