# Exemplo 9796: flatten vs ravel
# Objetivo: Comparar cópia (flatten) e view (ravel).
import numpy as np

A = np.arange(4*2).reshape(4, 2)
print("flatten len:", A.flatten().size)
print("ravel len:", A.ravel().size)
