# Exemplo 9850: np.percentile ao longo de eixo
# Objetivo: Percentil por coluna.
import numpy as np

A = np.arange(3*4).reshape(3, 4)
print("p50 por coluna:", np.percentile(A, 50, axis=0))
