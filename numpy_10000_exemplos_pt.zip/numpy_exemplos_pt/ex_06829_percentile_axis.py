# Exemplo 6829: np.percentile ao longo de eixo
# Objetivo: Percentil por coluna.
import numpy as np

A = np.arange(7*3).reshape(7, 3)
print("p50 por coluna:", np.percentile(A, 50, axis=0))
