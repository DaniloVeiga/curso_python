# Exemplo 4084: np.random.Generator.permutation
# Objetivo: Permutar elementos aleatoriamente.
import numpy as np

rng = np.random.default_rng(5318)
perm = rng.permutation(np.arange(7*2))
print("perm[0:10]:", perm[:10])
