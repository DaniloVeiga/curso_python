# Exemplo 1918: np.random.Generator.permutation
# Objetivo: Permutar elementos aleatoriamente.
import numpy as np

rng = np.random.default_rng(3152)
perm = rng.permutation(np.arange(6*4))
print("perm[0:10]:", perm[:10])
