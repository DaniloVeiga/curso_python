# Exemplo 8603: np.any e np.all
# Objetivo: Avaliar condições booleanas agregadas.
import numpy as np

x = np.arange(6*5)
print("algum > 13?", np.any(x > 13))
print("todos < 26?", np.all(x < 26))
