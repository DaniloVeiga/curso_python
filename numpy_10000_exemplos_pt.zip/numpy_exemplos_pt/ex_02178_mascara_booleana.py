# Exemplo 2178: Máscara booleana para filtragem
# Objetivo: Selecionar elementos maiores que um limiar.
import numpy as np

x = np.arange(6*4)
mask = x > 12
print("selecionados:", x[mask])
