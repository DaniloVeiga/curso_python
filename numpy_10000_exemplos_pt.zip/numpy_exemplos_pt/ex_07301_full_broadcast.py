# Exemplo 7301: np.full e broadcast em soma escalar
# Objetivo: Preencher matriz com valor fixo e somar escalar (broadcasting).
import numpy as np

A = np.full((4, 3), 7, dtype=float)
B = A + 11  # broadcasting do escalar
print("A =
", A)
print("B = A + 11 =
", B)
