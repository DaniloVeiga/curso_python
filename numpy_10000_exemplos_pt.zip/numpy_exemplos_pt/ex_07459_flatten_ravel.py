# Exemplo 7459: flatten vs ravel
# Objetivo: Comparar cópia (flatten) e view (ravel).
import numpy as np

A = np.arange(7*5).reshape(7, 5)
print("flatten len:", A.flatten().size)
print("ravel len:", A.ravel().size)
