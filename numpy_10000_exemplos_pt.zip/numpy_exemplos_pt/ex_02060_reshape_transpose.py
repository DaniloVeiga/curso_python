# Exemplo 2060: reshape e transpose
# Objetivo: Remodelar vetor em matriz e transpor.
import numpy as np

v = np.arange(3*2)
A = v.reshape(3, 2)
AT = A.T
print("A =
", A)
print("A.T =
", AT)
