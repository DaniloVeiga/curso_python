# Exemplo 9755: reshape e transpose
# Objetivo: Remodelar vetor em matriz e transpor.
import numpy as np

v = np.arange(3*5)
A = v.reshape(3, 5)
AT = A.T
print("A =
", A)
print("A.T =
", AT)
