# Exemplo 1557: np.unique com return_counts
# Objetivo: Encontrar valores únicos e suas contagens.
import numpy as np

x = np.array([1,2,2,3,3,3,4,4,5])
vals, cnt = np.unique(x, return_counts=True)
print("valores:", vals)
print("contagens:", cnt)
