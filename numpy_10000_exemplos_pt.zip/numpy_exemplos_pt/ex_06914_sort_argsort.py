# Exemplo 6914: np.sort e np.argsort
# Objetivo: Ordenar valores e obter índices de ordenação.
import numpy as np

rng = np.random.default_rng(8148)
x = rng.integers(0, 100, size=7*4)
print("x ordenado:", np.sort(x))
print("índices ordenação:", np.argsort(x))
