# Exemplo 3599: reshape e transpose
# Objetivo: Remodelar vetor em matriz e transpor.
import numpy as np

v = np.arange(7*5)
A = v.reshape(7, 5)
AT = A.T
print("A =
", A)
print("A.T =
", AT)
