# Exemplo 1602: np.random.default_rng().integers e operações básicas
# Objetivo: Gerar inteiros aleatórios e aplicar operações vetor/matriz.
import numpy as np

rng = np.random.default_rng(2836)
A = rng.integers(low=0, high=12, size=(5, 4))
B = rng.integers(low=0, high=12, size=(5, 4))
print("A =
", A)
print("B =
", B)
print("A + B =
", A + B)
print("A * B =
", A * B)
