# Exemplo 1924: np.stack no eixo 2
# Objetivo: Criar eixo de "camadas" (depth).
import numpy as np

A = np.arange(7*2).reshape(7, 2)
B = A + 6
C = np.stack([A, B], axis=2)
print("C.shape:", C.shape)
