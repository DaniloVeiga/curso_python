# Exemplo 6238: Broadcasting entre formas compatíveis
# Objetivo: Somar vetor (1x4) a matriz (6x4).
import numpy as np

A = np.arange(6*4).reshape(6, 4)
v = np.arange(4)
B = A + v
print("B.shape:", B.shape)
