# Exemplo 559: np.percentile ao longo de eixo
# Objetivo: Percentil por coluna.
import numpy as np

A = np.arange(7*5).reshape(7, 5)
print("p50 por coluna:", np.percentile(A, 50, axis=0))
