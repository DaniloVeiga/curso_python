# Exemplo 5746: np.percentile ao longo de eixo
# Objetivo: Percentil por coluna.
import numpy as np

A = np.arange(4*4).reshape(4, 4)
print("p50 por coluna:", np.percentile(A, 50, axis=0))
