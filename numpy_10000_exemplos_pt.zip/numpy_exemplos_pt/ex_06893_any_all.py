# Exemplo 6893: np.any e np.all
# Objetivo: Avaliar condições booleanas agregadas.
import numpy as np

x = np.arange(6*3)
print("algum > 7?", np.any(x > 7))
print("todos < 14?", np.all(x < 14))
