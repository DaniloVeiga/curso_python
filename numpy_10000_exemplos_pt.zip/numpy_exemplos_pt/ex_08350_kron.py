# Exemplo 8350: Produto de Kronecker (np.kron)
# Objetivo: Expandir matrizes via produto de Kronecker.
import numpy as np

A = np.arange(3).reshape(3, 1)
B = np.ones((4, 3))
K = np.kron(A, B)
print("K.shape:", K.shape)
