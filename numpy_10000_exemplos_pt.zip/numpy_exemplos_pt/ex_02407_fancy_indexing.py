# Exemplo 2407: Indexação avançada (fancy indexing)
# Objetivo: Indexar com lista de posições específicas.
import numpy as np

x = np.arange(20)
idxs = np.array([9, 1, 10])
print("x[idxs] =", x[idxs])
