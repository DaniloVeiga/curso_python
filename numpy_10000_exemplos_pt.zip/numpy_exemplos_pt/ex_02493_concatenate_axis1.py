# Exemplo 2493: np.concatenate em axis=1
# Objetivo: Concatenar matrizes horizontalmente.
import numpy as np

A = np.arange(6*3).reshape(6, 3)
B = np.arange(6*2).reshape(6, 2)
C = np.concatenate([A, B], axis=1)
print("C.shape:", C.shape)
