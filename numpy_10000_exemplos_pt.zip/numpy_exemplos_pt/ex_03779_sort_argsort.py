# Exemplo 3779: np.sort e np.argsort
# Objetivo: Ordenar valores e obter índices de ordenação.
import numpy as np

rng = np.random.default_rng(5013)
x = rng.integers(0, 100, size=7*5)
print("x ordenado:", np.sort(x))
print("índices ordenação:", np.argsort(x))
