# Exemplo 9929: np.array_split para dividir vetor
# Objetivo: Dividir um vetor em partes quase iguais.
import numpy as np

x = np.arange(7*3)
parts = np.array_split(x, 3)
print([p.size for p in parts])
