# Exemplo 9201: np.percentile e np.median
# Objetivo: Estatísticas de posição.
import numpy as np

rng = np.random.default_rng(10435)
x = rng.normal(size=50)
print("mediana:", float(np.median(x)))
print("p90:", float(np.percentile(x, 90)))
