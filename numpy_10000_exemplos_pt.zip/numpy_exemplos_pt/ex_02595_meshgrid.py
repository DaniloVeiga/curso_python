# Exemplo 2595: np.meshgrid para avaliação em grade
# Objetivo: Criar grade 2D e avaliar função f(x,y).
import numpy as np

x = np.linspace(-1, 1, 5)
y = np.linspace(-1, 1, 3)
X, Y = np.meshgrid(x, y)
Z = X**2 + Y**2
print("Z.shape:", Z.shape)
