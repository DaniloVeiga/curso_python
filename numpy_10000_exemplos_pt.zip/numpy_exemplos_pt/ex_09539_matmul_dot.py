# Exemplo 9539: Produto matricial (matmul / dot)
# Objetivo: Multiplicar matrizes 2D.
import numpy as np

A = np.arange(7*5).reshape(7, 5)
B = np.arange(5*4).reshape(5, 4)
C = A @ B
print("C.shape:", C.shape)
