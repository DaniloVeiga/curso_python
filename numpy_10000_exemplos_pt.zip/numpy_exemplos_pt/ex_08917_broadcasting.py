# Exemplo 8917: Broadcasting entre formas compatíveis
# Objetivo: Somar vetor (1x3) a matriz (5x3).
import numpy as np

A = np.arange(5*3).reshape(5, 3)
v = np.arange(3)
B = A + v
print("B.shape:", B.shape)
