# Exemplo 6380: np.any e np.all
# Objetivo: Avaliar condições booleanas agregadas.
import numpy as np

x = np.arange(3*2)
print("algum > 10?", np.any(x > 10))
print("todos < 14?", np.all(x < 14))
