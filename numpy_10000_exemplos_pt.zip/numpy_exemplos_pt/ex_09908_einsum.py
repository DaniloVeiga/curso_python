# Exemplo 9908: np.einsum para multiplicação matriz-vetor
# Objetivo: Usar einsum em operação equivalente a A@x.
import numpy as np

A = np.arange(6*2).reshape(6, 2)
x = np.arange(2)
y = np.einsum('ij,j->i', A, x)
print("y:", y)
