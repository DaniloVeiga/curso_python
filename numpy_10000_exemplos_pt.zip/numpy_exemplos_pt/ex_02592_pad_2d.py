# Exemplo 2592: np.pad em 2D
# Objetivo: Preencher bordas de uma matriz com constante.
import numpy as np

A = np.arange(5*2).reshape(5, 2)
P = np.pad(A, pad_width=1, mode='constant', constant_values=-1)
print("P.shape:", P.shape)
