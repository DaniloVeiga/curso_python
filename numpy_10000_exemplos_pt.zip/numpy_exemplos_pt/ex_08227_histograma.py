# Exemplo 8227: np.histogram
# Objetivo: Calcular histograma de dados.
import numpy as np

rng = np.random.default_rng(9461)
x = rng.normal(size=100)
h, edges = np.histogram(x, bins=7)
print("h:", h)
print("edges:", edges)
