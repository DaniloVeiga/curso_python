# Exemplo 9064: Criação de array 1D com np.arange(6, 28, 2)
# Objetivo: Demonstrar a criação de sequências com intervalos regulares.
import numpy as np

a = np.arange(6, 28, 2)
print("a =", a)
print("tamanho:", a.size, "min:", a.min(), "max:", a.max())
