# Exemplo 1776: np.concatenate em axis=0
# Objetivo: Concatenar duas matrizes verticalmente.
import numpy as np

A = np.arange(4*2).reshape(4, 2)
B = np.arange(4*2, 4*2*2).reshape(4, 2)
C = np.concatenate([A, B], axis=0)
print("C.shape:", C.shape)
