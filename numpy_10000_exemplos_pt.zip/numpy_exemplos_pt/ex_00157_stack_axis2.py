# Exemplo 157: np.stack no eixo 2
# Objetivo: Criar eixo de "camadas" (depth).
import numpy as np

A = np.arange(5*3).reshape(5, 3)
B = A + 3
C = np.stack([A, B], axis=2)
print("C.shape:", C.shape)
