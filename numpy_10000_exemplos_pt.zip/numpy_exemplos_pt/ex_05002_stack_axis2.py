# Exemplo 5002: np.stack no eixo 2
# Objetivo: Criar eixo de "camadas" (depth).
import numpy as np

A = np.arange(5*4).reshape(5, 4)
B = A + 12
C = np.stack([A, B], axis=2)
print("C.shape:", C.shape)
