# Exemplo 3184: flatten vs ravel
# Objetivo: Comparar cópia (flatten) e view (ravel).
import numpy as np

A = np.arange(7*2).reshape(7, 2)
print("flatten len:", A.flatten().size)
print("ravel len:", A.ravel().size)
