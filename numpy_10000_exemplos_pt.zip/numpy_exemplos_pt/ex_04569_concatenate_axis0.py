# Exemplo 4569: np.concatenate em axis=0
# Objetivo: Concatenar duas matrizes verticalmente.
import numpy as np

A = np.arange(7*3).reshape(7, 3)
B = np.arange(7*3, 7*3*2).reshape(7, 3)
C = np.concatenate([A, B], axis=0)
print("C.shape:", C.shape)
