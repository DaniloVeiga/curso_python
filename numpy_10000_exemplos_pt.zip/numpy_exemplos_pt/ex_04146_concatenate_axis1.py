# Exemplo 4146: np.concatenate em axis=1
# Objetivo: Concatenar matrizes horizontalmente.
import numpy as np

A = np.arange(4*4).reshape(4, 4)
B = np.arange(4*2).reshape(4, 2)
C = np.concatenate([A, B], axis=1)
print("C.shape:", C.shape)
