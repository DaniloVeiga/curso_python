# Exemplo 8351: np.tile e np.repeat
# Objetivo: Repetir padrões em vetores.
import numpy as np

x = np.arange(5)
print("tile:", np.tile(x, 4))
print("repeat:", np.repeat(x, 4))
