# Exemplo 9010: np.ones com dtype=int e forma (3,4)
# Objetivo: Criar matriz de uns com tipo inteiro.
import numpy as np

O = np.ones((3, 4), dtype=int)
print("O =
", O)
print("dtype:", O.dtype)
