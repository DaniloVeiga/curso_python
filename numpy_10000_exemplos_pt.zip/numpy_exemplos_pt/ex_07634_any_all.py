# Exemplo 7634: np.any e np.all
# Objetivo: Avaliar condições booleanas agregadas.
import numpy as np

x = np.arange(7*4)
print("algum > 4?", np.any(x > 4))
print("todos < 6?", np.all(x < 6))
