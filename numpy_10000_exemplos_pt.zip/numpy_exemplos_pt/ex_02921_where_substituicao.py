# Exemplo 2921: np.where para substituição condicional
# Objetivo: Substituir valores baseado em condição.
import numpy as np

x = np.arange(4*3)
y = np.where(x % 2 == 0, x, -1)
print("y =", y)
