# Exemplo 2375: np.bincount
# Objetivo: Contar ocorrências de inteiros não negativos.
import numpy as np

x = np.array([0,1,1,2,2,2,3,3,4])
print("bincount:", np.bincount(x))
