# Exemplo 1057: np.vectorize para função escalar
# Objetivo: Vetorizar uma função escalar com np.vectorize.
import numpy as np

def f(t):
    return t*t + 1
v = np.vectorize(f)
x = np.arange(5*3)
print("v(x)[0:5] =", v(x)[:5])
